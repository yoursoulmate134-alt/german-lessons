package com.germanlessons.app

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.RecognitionListener
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.View
import android.widget.*
import java.util.Locale

private data class Phrase(val level:String,val topic:String,val de:String,val en:String,val note:String)

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private val bg = Color.rgb(12,12,19)
    private val panel = Color.rgb(27,27,41)
    private val purple = Color.rgb(197,157,255)
    private val white = Color.rgb(247,244,255)
    private val muted = Color.rgb(183,178,200)
    private lateinit var tts: TextToSpeech
    private var recognizer: SpeechRecognizer? = null
    private var level = "A1"
    private var index = 0
    private var meaningVisible = true
    private var callMode = false
    private lateinit var root: LinearLayout
    private lateinit var status: TextView
    private lateinit var phraseGerman: TextView
    private lateinit var phraseEnglish: TextView
    private lateinit var phraseNote: TextView
    private lateinit var counter: TextView
    private val phrases = listOf(
        Phrase("A1","Greetings","Hallo! Wie geht es dir?","Hello! How are you?","Hallo = hello · Wie geht es dir? = how are you?"),
        Phrase("A1","Introduce yourself","Ich heiße …","My name is …","Ich heiße = my name is / I am called"),
        Phrase("A1","Where you live","Ich wohne in Indien.","I live in India.","wohne = live · in = in"),
        Phrase("A1","Learning German","Ich lerne Deutsch.","I am learning German.","lerne = learn · Deutsch = German"),
        Phrase("A1","Likes","Ich mag Musik und Kunst.","I like music and art.","mag = like · Musik = music · Kunst = art"),
        Phrase("A1","Ask for help","Können Sie mir bitte helfen?","Could you please help me?","Können Sie = could you (polite) · helfen = help"),
        Phrase("A1","At a café","Ich hätte gern einen Tee, bitte.","I would like a tea, please.","Ich hätte gern = I would like"),
        Phrase("A1","Thank someone","Vielen Dank!","Thank you very much!","Vielen Dank = thank you very much"),
        Phrase("A1","Say you don't understand","Ich verstehe das nicht.","I don't understand that.","verstehe = understand · nicht = not"),
        Phrase("A2","Daily routine","Ich stehe um sieben Uhr auf.","I get up at seven o'clock.","aufstehen is separable: auf moves to the end"),
        Phrase("A2","Shopping","Wie viel kostet das?","How much does that cost?","Wie viel = how much · kostet = costs"),
        Phrase("B1","Give a reason","Ich lerne Deutsch, weil ich in Deutschland studieren möchte.","I learn German because I want to study in Germany.","After weil, the conjugated verb goes to the end"),
        Phrase("B2","Give an opinion","Meiner Meinung nach ist Übung wichtig.","In my opinion, practice is important.","Meiner Meinung nach = in my opinion"),
        Phrase("C1","Although","Obwohl die Aufgabe schwierig ist, bleibe ich ruhig.","Although the task is difficult, I stay calm.","Obwohl starts a subordinate clause"),
        Phrase("C2","Nuanced expression","Es wäre vorschnell, daraus Schlüsse zu ziehen.","It would be premature to draw conclusions from that.","wäre is Konjunktiv II of sein")
    )

    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); window.statusBarColor=bg; window.navigationBarColor=bg; window.decorView.systemUiVisibility=0; tts=TextToSpeech(this,this); showHome() }

    private fun base(title:String, subtitle:String?=null): LinearLayout {
        root=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(20,18,20,16); setBackgroundColor(bg) }
        val scroll=ScrollView(this); scroll.addView(root); setContentView(scroll)
        root.addView(text(title,28,white,true,Gravity.START).apply { setPadding(0,4,0,3) })
        if(subtitle!=null) root.addView(text(subtitle,14,muted).apply { setPadding(0,0,0,18) })
        return root
    }
    private fun text(s:String,size:Int,color:Int=white,bold:Boolean=false,gravity:Int=Gravity.START)=TextView(this).apply { text=s; textSize=size.toFloat(); setTextColor(color); this.gravity=gravity; if(bold) setTypeface(null,Typeface.BOLD); setPadding(2,5,2,5) }
    private fun card(): LinearLayout = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(16,14,16,14); background=shape(panel,22); layoutParams=LinearLayout.LayoutParams(-1,-2).apply{bottomMargin=12} }
    private fun shape(color:Int,r:Float)=GradientDrawable().apply{setColor(color);cornerRadius=r}
    private fun btn(label:String, action:()->Unit, primary:Boolean=false): Button = Button(this).apply { text=label; isAllCaps=false; textSize=15f; setTextColor(if(primary) Color.rgb(24,18,35) else white); background=shape(if(primary) purple else panel,18f); setPadding(10,7,10,7); setOnClickListener{action()} ; layoutParams=LinearLayout.LayoutParams(-1,-2).apply{bottomMargin=9} }
    private fun gap(parent:LinearLayout,h:Int=8){parent.addView(View(this),LinearLayout.LayoutParams(1,h))}
    private fun showHome(){ callMode=false; base("German Lessons 🇩🇪","Learn German your way · Free core lessons")
        val hero=card(); hero.addView(text("Hallo! I'm Cyra 💜",21,white,true)); hero.addView(text("Your friendly German teacher. Learn quietly with lessons or practise speaking with me on a call.",15,muted)); root.addView(hero)
        val levelCard=card(); levelCard.addView(text("Choose your level",17,white,true)); val row=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL}
        listOf("A1","A2","B1","B2","C1","C2").forEach{ l-> val b=Button(this).apply{text=l;isAllCaps=false;textSize=13f;setTextColor(if(level==l) Color.BLACK else white);background=shape(if(level==l) purple else panel,14f);setOnClickListener{level=l;index=0;showHome()};layoutParams=LinearLayout.LayoutParams(0,48,1f).apply{setMargins(2,3,2,3)}};row.addView(b) }
        levelCard.addView(row); root.addView(levelCard)
        val lesson=card(); lesson.addView(text("📚  Learn without calling",18,white,true)); lesson.addView(text("Read phrases, hear German pronunciation, see English meanings, and practise by speaking or typing.",14,muted)); lesson.addView(btn("Open lessons  →",{showLessons()},true)); root.addView(lesson)
        val call=card(); call.addView(text("🎙️  Talk with Cyra",18,white,true)); call.addView(text("A call-style screen with Cyra's anime portrait, spoken German, and gentle corrections. Microphone support depends on your phone's speech service.",14,muted)); call.addView(btn("Start practice call",{showCall()},true)); root.addView(call)
        val note=card(); note.addView(text("What works offline?",16,white,true)); note.addView(text("Sample lessons, English explanations, and spoken phrase playback can work without a paid AI subscription. Open-ended AI conversations are not included in this starter version.",13,muted)); root.addView(note)
    }
    private fun current():List<Phrase> = phrases.filter{it.level==level}
    private fun showLessons(){callMode=false;base("Lessons","Quiet mode · No calls needed")
        val levelsRow=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL}
        listOf("A1","A2","B1","B2","C1","C2").forEach{l->levelsRow.addView(Button(this).apply{text=l;isAllCaps=false;textSize=12f;setTextColor(if(level==l)Color.BLACK else white);background=shape(if(level==l)purple else panel,12f);setOnClickListener{level=l;index=0;showLessons()};layoutParams=LinearLayout.LayoutParams(0,46,1f).apply{setMargins(2,2,2,2)}})}
        root.addView(levelsRow);gap(root,10)
        val list=current(); if(list.isEmpty()) return
        index=index.coerceIn(0,list.lastIndex); val p=list[index]
        val c=card(); c.addView(text("${p.level} · ${p.topic}",16,purple,true)); c.addView(text(p.de,25,white,true,Gravity.CENTER).apply{setPadding(2,24,2,12)}); if(meaningVisible)c.addView(text(p.en,18,purple,false,Gravity.CENTER)); c.addView(text(if(meaningVisible)p.note else "English meaning hidden",14,muted)); c.addView(btn("🔊  Hear German",{speak(p.de,0.82f)},true)); c.addView(btn("🐢  Hear slowly",{speak(p.de,0.58f)})); c.addView(btn("🎤  Say it aloud",{listenFor(p.de)})); c.addView(btn(if(meaningVisible)"Hide English meaning" else "Show English meaning",{meaningVisible=!meaningVisible;showLessons()})); root.addView(c)
        root.addView(text("Lesson ${index+1} of ${list.size}",13,muted, false,Gravity.CENTER)); val nav=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL}; nav.addView(btn("← Previous",{index=(index-1).coerceAtLeast(0);showLessons()}),LinearLayout.LayoutParams(0,-2,1f)); nav.addView(btn("Next →",{index=(index+1).coerceAtMost(list.lastIndex);showLessons()},true),LinearLayout.LayoutParams(0,-2,1f));root.addView(nav);root.addView(btn("⌂  Home",{showHome()}))
    }
    private fun showCall(){callMode=true;base("Cyra AI","German practice call · Guided voice mode")
        val c=card(); val portrait=ImageView(this).apply{setImageResource(com.germanlessons.app.R.drawable.cyra_portrait);scaleType=ImageView.ScaleType.CENTER_CROP;background=shape(purple,300f);clipToOutline=true;layoutParams=LinearLayout.LayoutParams(250,250).apply{gravity=Gravity.CENTER;bottomMargin=12}}
        c.addView(portrait);c.addView(text("Cyra",22,white,true,Gravity.CENTER));c.addView(text("Hallo! 😊 Wie geht es dir heute?",18,purple,true,Gravity.CENTER));c.addView(text("Hello! How are you today?",15,muted,false,Gravity.CENTER));root.addView(c)
        val response=card();response.addView(text("Let's practise",17,white,true));response.addView(text("Say a German sentence with the microphone, or tap a reply below. I'll speak the German and explain it in English.",14,muted));status=text("Cyra is ready when you are 💜",14,purple);response.addView(status);response.addView(btn("🎤  Talk to Cyra",{listenConversation()},true));response.addView(btn("🔊  Hear Cyra's greeting",{speak("Hallo! Wie geht es dir heute?",0.8f)}));root.addView(response)
        val quick=card();quick.addView(text("Quick replies",16,white,true));listOf("Mir geht es gut. = I'm doing well.","Ich heiße … = My name is …","Ich verstehe nicht. = I don't understand.","Kannst du das wiederholen? = Can you repeat that?").forEach{line->quick.addView(btn(line,{val de=line.substringBefore(" =");speak(de,0.8f);status.text="Sehr gut! Let's practise: $line"}))};root.addView(quick);root.addView(btn("End call · Back to lessons",{showHome()}))
    }
    private fun speak(s:String,rate:Float){if(!::tts.isInitialized)return; tts.language=Locale.GERMANY;tts.setSpeechRate(rate);tts.speak(s,TextToSpeech.QUEUE_FLUSH,null,"cyra-${System.currentTimeMillis()}")}
    private fun listenConversation(){listenFor(null)}
    private fun listenFor(target:String?){
        if(!SpeechRecognizer.isRecognitionAvailable(this)){if(::status.isInitialized)status.text="Speech recognition isn't available. You can still use the listening buttons.";return}
        if(checkSelfPermission(Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED){requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO),42);if(::status.isInitialized)status.text="Allow microphone access, then tap the microphone again.";return}
        try{recognizer?.destroy();recognizer=SpeechRecognizer.createSpeechRecognizer(this);recognizer?.setRecognitionListener(object:RecognitionListener{
            override fun onReadyForSpeech(params:Bundle?){if(::status.isInitialized)status.text="I'm listening… say a short sentence in German 🎙️"}
            override fun onBeginningOfSpeech(){};override fun onRmsChanged(rmsdB:Float){};override fun onBufferReceived(buffer:ByteArray?){}
            override fun onEndOfSpeech(){if(::status.isInitialized)status.text="One moment, I'm checking what I heard…"}
            override fun onError(error:Int){if(::status.isInitialized)status.text="I couldn't hear that clearly. Try again slowly, or use a quick reply."}
            override fun onResults(results:Bundle?){val said=results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty();if(!::status.isInitialized)return
                if(target!=null){val close=norm(said)==norm(target);status.text=if(close)"Sehr gut! 🎉 I heard: $said" else "I heard: “$said”. Target: “$target”. Try slowly—speech recognition isn't always exact.";speak(if(close)"Sehr gut! Das hast du gut gemacht." else "Gute Arbeit beim Üben. Noch einmal, bitte.",0.78f)}
                else {val reply=when{said.contains("gut",true)->"Sehr gut! Das freut mich. = Very good! I'm glad. Let's try: Was machst du gern? = What do you like to do?";said.contains("heiße",true)||said.contains("heisse",true)->"Freut mich! = Nice to meet you! You can ask me: Wie heißt du? = What's your name?";said.contains("nicht",true)||said.contains("verstehe",true)->"Kein Problem! = No problem! Ich erkläre es auf Englisch. = I'll explain it in English.";else->"Sehr schön, dass du übst! = It's great that you're practising! Try saying: Ich lerne Deutsch. = I am learning German."};status.text="You: $said\n\nCyra: $reply";speak(reply.substringBefore(" ="),0.78f)} }
            override fun onPartialResults(partialResults:Bundle?){};override fun onEvent(eventType:Int,params:Bundle?){}
        });val intent=Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply{putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);putExtra(RecognizerIntent.EXTRA_LANGUAGE,"de-DE");putExtra(RecognizerIntent.EXTRA_PROMPT,"Talk to Cyra in German")};recognizer?.startListening(intent)}catch(e:Exception){if(::status.isInitialized)status.text="Couldn't start the microphone. Check permissions and try again."}
    }
    private fun norm(s:String)=s.lowercase(Locale.GERMAN).replace("ä","a").replace("ö","o").replace("ü","u").replace("ß","ss").replace(Regex("[^a-z0-9 ]"),"").replace(Regex("\\s+")," ").trim()
    override fun onInit(result:Int){if(result==TextToSpeech.SUCCESS)tts.language=Locale.GERMANY}
    override fun onRequestPermissionsResult(requestCode:Int,permissions:Array<out String>,grantResults:IntArray){super.onRequestPermissionsResult(requestCode,permissions,grantResults);if(requestCode==42&&grantResults.isNotEmpty()&&grantResults[0]==PackageManager.PERMISSION_GRANTED){if(::status.isInitialized)status.text="Microphone ready! Tap the microphone again."}else if(::status.isInitialized)status.text="No microphone permission. You can still learn quietly."}
    override fun onDestroy(){recognizer?.destroy();if(::tts.isInitialized){tts.stop();tts.shutdown()};super.onDestroy()}
}
